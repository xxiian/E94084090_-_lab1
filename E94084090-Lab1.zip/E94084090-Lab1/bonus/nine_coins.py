#!/usr/bin/env python
# coding: utf-8

# In[ ]:


list=[]
a=[]
import random
def binary(num):
    for i in range(9):
        if num!=0:
            r=num%2
            num=num//2
            list.append(r)
        else:
            r=0
            list.append(r)
    for j in list[::-1]:
        return j
class Nine_Coins:
    def __init__(self,num):
        self.num=num
        self.bin=binary(num)
    def __repr__(self):
        for i in list[::-1]:
            if i==0:
                 a.append("H")
            else:
                 a.append("T")
        string='%s'*len(a) % tuple(a) 
        del a[:]
        return f"Nine_Coins:{string}"
    def __str__(self):
        list.reverse()
        s='%s'*len(list) % tuple(list) 
        return f"binary:{s} and decimal:{self.num}"
    def toss(self):
        num=random.randint(0,511)
        self.num=num
        del list[:]
        binary(num)

